#include "widget.h"
#include "ui_widget.h"


Widget::Widget(QWidget *parent)
    : QWidget(parent)   
    , ui(new Ui::Widget)
    , port(new QSerialPort(this))
{
    ui->setupUi(this);
    connect(ui->pushButton, &QPushButton::released, this, &Widget::buttonfunc);
    connect(ui->pushButton_2, &QPushButton::released, this, &Widget::buttonfunc2);
    openport();


}

Widget::~Widget()
{
    delete ui;
}

void Widget::buttonfunc(void)
{

    //port->open(QIODevice::ReadWrite);
    //    serial.close();
    //char * data = "test\n";
    //senddata.replace(0,5,"ledo\n");
    strcpy_s(senddata,"ledon");
    port->write(senddata, 5);//qstrlen(senddata));
    qDebug()<<qstrlen(senddata) <<"byte senddata";
}
void Widget::buttonfunc2(void)
{

    //port->open(QIODevice::ReadWrite);
    //    serial.close();
    //char * data = "test\n";
    //senddata.replace(0,5,"ledo\n");
    strcpy_s(senddata,"ledof");
    port->write(senddata, 5);//qstrlen(senddata));
    qDebug()<<qstrlen(senddata) <<"byte senddata";
}
void Widget::readData(void)
{
    //qDebug()<< "readdata";
    //qint32 i = 0;
    AvailableData = port->bytesAvailable();
#if 0
    while(AvailableData != 5)
    {
        qDebug()<<AvailableData<<" byte come";
        AvailableData = port->bytesAvailable();
        i++;
        if(i > 5)
        {
            break;
        }
    }
#endif
    //QByteArray temp = port->readLine();
    if(AvailableData == 5)
    {
        QByteArray temp = port->readAll();
        qDebug()<<temp;
        ui->textEdit->setPlainText((QString)temp);
    }
    //qint64 QSerialPort::readLineData(char *data, qint64 maxSize)
    //m_console->putData(data);

}

void Widget::openport(void)
{
    port = new QSerialPort();
    port->setPortName("COM5");
    port->setBaudRate(QSerialPort::Baud115200);
    port->setDataBits(QSerialPort::Data8);
    port->setParity(QSerialPort::NoParity);
    port->setStopBits(QSerialPort::OneStop);
    port->setFlowControl(QSerialPort::NoFlowControl);
    port->open(QIODevice::ReadWrite);
    connect(port, &QSerialPort::readyRead, this, &Widget::readData);
}
