#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QtSerialPort/QSerialPort>
#include <QDebug>
#include <string.h>
#include <stdio.h>
//#include <QIODevice>
//#include <QSerialPort>
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    void openport(void);
    //QSerialPort *serial; //plus

private slots:
    void buttonfunc(void);
    void buttonfunc2(void);
    void readData(void);

private:
    Ui::Widget *ui;
    QSerialPort *port;
    char senddata[6] = "test\n";
    qint64 AvailableData = 0;
};
#endif // WIDGET_H
